const loginForm = document.getElementById("login-form");
const loginButton = document.getElementById("login-form-submit");
const loginErrorMsg = document.getElementById("login-error-msg");
var pass = btoa("SnailsR0ck");

loginButton.addEventListener("click", (e) => {
  e.preventDefault();
  const username = loginForm.username.value;
  const password = loginForm.password.value;

  if (username === "Gary" && password === pass) {
    window.location.replace("secret.html");
  } else {
    loginErrorMsg.style.opacity = 1;
  }
})
